class ColorGenerator
  VERSION = "0.0.4"
end
