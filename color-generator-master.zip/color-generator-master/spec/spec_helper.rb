require 'rubygems'

require 'coveralls'
Coveralls.wear!

require 'rspec'
require File.dirname(__FILE__) + '/../lib/color-generator'
